# Dice-Soup
More textures for the Dice So Nice module on FoundryVTT.
Textures for this module are marked with 🔮crystal ball before the label.
All images used are from Unsplash.com

![dice samples](https://github.com/riverstyx09/Dice-Soup/blob/master/dicesample.gif?raw=true)
