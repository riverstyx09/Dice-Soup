# 🔮 Dice Soup

![dice samples](https://github.com/riverstyx09/Dice-Soup/blob/master/dicesample.gif?raw=true)


36 textures,
5 sytems,
and
6 color sets
added to the Dice So Nice Module from Unsplash.

![dice preview #1](https://github.com/riverstyx09/Dice-Soup/blob/master/dicesoup_previews.png?raw=true)
